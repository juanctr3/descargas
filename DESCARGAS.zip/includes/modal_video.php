<div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="videoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body bg-dark p-0">
                <button type="button" class="btn-close btn-close-white" style="position: absolute; top: 1rem; right: 1rem; z-index: 2;" data-bs-dismiss="modal" aria-label="Close"></button>
                
                <div class="ratio ratio-16x9">
                    <iframe src="" title="Video de YouTube" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>