<?php

namespace MercadoPago\Resources\Payment;

/** Order class. */
class Order
{

    /** Order ID. */
    public ?int $id;

    /** Type. */
    public ?string $type;

}
