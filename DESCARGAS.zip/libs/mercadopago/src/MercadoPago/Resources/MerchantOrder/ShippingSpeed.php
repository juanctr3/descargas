<?php

namespace MercadoPago\Resources\MerchantOrder;

class ShippingSpeed
{
    /** Handling time. */
    public ?int $handling;

    /** Shipping time. */
    public ?int $shipping;
}
