<?php

namespace MercadoPago\Resources\MerchantOrder;

class ReceiverAddressState
{
    /** State ID. */
    public ?string $id;

    /** State name. */
    public ?string $name;
}
