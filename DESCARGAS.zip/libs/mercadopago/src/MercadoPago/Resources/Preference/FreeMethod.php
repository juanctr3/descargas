<?php

namespace MercadoPago\Resources\Preference;

/** FreeMethod class. */
class FreeMethod
{
    /** Shipping method ID. */
    public ?int $id;
}
